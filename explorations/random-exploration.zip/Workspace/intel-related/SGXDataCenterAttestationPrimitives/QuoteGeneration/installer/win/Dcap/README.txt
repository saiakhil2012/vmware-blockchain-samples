Steps to generate sgx_dcap.inf installer:
1.Execute "dcap_copy_file.bat" to copy and sign the dependency files.
2.Execute "dcap_generate.bat" to generate the .inf installer. As example: dcap_generate.bat 1.0.0.0