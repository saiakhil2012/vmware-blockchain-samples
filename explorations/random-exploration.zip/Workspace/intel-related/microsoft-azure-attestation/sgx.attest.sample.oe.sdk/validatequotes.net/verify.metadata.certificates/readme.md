# VerifyMetadataCertificates
The code in this directory is copied/pasted from Larry Osterman's github repo here: 

https://github.com/LarryOsterman/RetrieveAndVerifyMetadataCerts/tree/master/VerifyMetadataCertificates

Many thanks to Larry for developing and sharing this code!