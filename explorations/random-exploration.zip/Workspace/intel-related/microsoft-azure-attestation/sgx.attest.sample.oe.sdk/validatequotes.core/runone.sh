dotnet run ../genquotes/quotes/enclave.info.prodid.json    sharedcus.cus.attest.azure.net   true

