dotnet run ../genquotes/out/enclave.info.prodid.json    sharedcus.cus.attest.azure.net   true

